% Crisptofer Fern�ndez
% 19/10/18
% function1 de Tarea05

% E: values of 'x' y 'y' that the function takes
% S: answer of the function when evaluated in the given points
function f = function1(x,y)
  f = x*y^(2);
endfunction