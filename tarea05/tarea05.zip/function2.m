% Andr�s Ram�rez
% 20/10/18
% function2 de Tarea05

% E: values of 'x' y 'y' that the function takes
% S: answer of the function when evaluated in the given points
function f = function2(x,y)
  f = 100 - y;
endfunction