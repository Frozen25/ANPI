var searchData=
[
  ['what',['what',['../de/d35/classanpi_1_1Exception.html#a58705160e813607d2ac15cfe0563aab0',1,'anpi::Exception']]],
  ['write',['write',['../dc/de2/namespaceanpi_1_1benchmark.html#acbe6f0f44f90b9b7861e08dc1e9231d3',1,'anpi::benchmark::write(std::ostream &amp;stream, const std::vector&lt; measurement &gt; &amp;m)'],['../dc/de2/namespaceanpi_1_1benchmark.html#a7ef3ea8c9c9a8b79e1e37df28b3615ce',1,'anpi::benchmark::write(const std::string &amp;filename, const std::vector&lt; measurement &gt; &amp;m)']]]
];
