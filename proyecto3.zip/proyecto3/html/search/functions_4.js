var searchData=
[
  ['data',['data',['../de/dee/classanpi_1_1Matrix.html#ae5c95a5664b8e29ead8227b3fc279d20',1,'anpi::Matrix::data()'],['../de/dee/classanpi_1_1Matrix.html#a326c01e733447563d4b1339d7fb7f07b',1,'anpi::Matrix::data() const']]],
  ['dcols',['dcols',['../de/dee/classanpi_1_1Matrix.html#a594c8611746bd66eb00929cb300d8679',1,'anpi::Matrix']]],
  ['desc',['desc',['../df/df5/program__options_8cpp.html#ab4cabbc710d5e3fc4bc15d17c6baadde',1,'program_options.cpp']]]
];
