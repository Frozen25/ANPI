var searchData=
[
  ['aligned_5fallocator',['aligned_allocator',['../d4/d2f/classanpi_1_1aligned__allocator.html',1,'anpi']]],
  ['aligned_5frow_5fallocator',['aligned_row_allocator',['../d4/df0/classanpi_1_1aligned__row__allocator.html',1,'anpi']]]
];
