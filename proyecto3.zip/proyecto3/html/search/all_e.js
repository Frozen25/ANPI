var searchData=
[
  ['pivot',['pivot',['../dd/d18/namespaceanpi.html#a28b5b58719a454e2a5e8343a9c035d06',1,'anpi']]],
  ['platform_5fid',['PLATFORM_ID',['../d6/d83/CMakeCXXCompilerId_8cpp.html#adbc5372f40838899018fadbc89bd588b',1,'CMakeCXXCompilerId.cpp']]],
  ['plot',['plot',['../d6/dfc/classanpi_1_1Plot2d.html#a0b04dd4c40f9f623789fa688bd3c593d',1,'anpi::Plot2d::plot(const std::vector&lt; T &gt; &amp;datax, const std::vector&lt; T &gt; &amp;datay, const std::string &amp;legend, const std::string &amp;color=&quot;&quot;)'],['../d6/dfc/classanpi_1_1Plot2d.html#ad7978a6d763c92036ca249982a041dd1',1,'anpi::Plot2d::plot(const std::vector&lt; T &gt; &amp;datax, const std::vector&lt; T &gt; &amp;averagey, const std::vector&lt; T &gt; &amp;miny, const std::vector&lt; T &gt; &amp;maxy, const std::string &amp;legend, const std::string &amp;color=&quot;r&quot;)'],['../dc/de2/namespaceanpi_1_1benchmark.html#a2342edf4630c65e3bb493d4327aaf2e5',1,'anpi::benchmark::plot()']]],
  ['plot2d',['Plot2d',['../d6/dfc/classanpi_1_1Plot2d.html',1,'anpi::Plot2d&lt; T &gt;'],['../d6/dfc/classanpi_1_1Plot2d.html#a0d7d01999364a90882de6b19bdd0245b',1,'anpi::Plot2d::Plot2d()']]],
  ['plotpy_2ehpp',['PlotPy.hpp',['../d9/dfb/PlotPy_8hpp.html',1,'']]],
  ['plotpy_2etpp',['PlotPy.tpp',['../d8/d09/PlotPy_8tpp.html',1,'']]],
  ['plotrange',['plotRange',['../dc/de2/namespaceanpi_1_1benchmark.html#a58babb1b967728c138790779206a61a1',1,'anpi::benchmark']]],
  ['plotthermal',['plotThermal',['../d6/dfc/classanpi_1_1Plot2d.html#aea73e92ff640dc6e16fbe0fd3e588667',1,'anpi::Plot2d']]],
  ['pointer',['pointer',['../de/dee/classanpi_1_1Matrix.html#a6d2754ddec71081f6e1c0e4c320e8f8e',1,'anpi::Matrix']]],
  ['prepare',['prepare',['../d9/d9d/classbenchAdd.html#a42b0ce6b2d78a84bb89e135517f65d4a',1,'benchAdd::prepare()'],['../d6/dfc/classbenchSub.html#a00120c49297be543c5d5e65289405eec',1,'benchSub::prepare()']]],
  ['program_5foptions_2ecpp',['program_options.cpp',['../df/df5/program__options_8cpp.html',1,'']]],
  ['pymat_5frow',['pymat_row',['../dd/d18/namespaceanpi.html#a924781fa0b7a5031d898921010dbd01c',1,'anpi']]]
];
