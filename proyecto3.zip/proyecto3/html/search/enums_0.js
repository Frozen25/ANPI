var searchData=
[
  ['initializationtype',['InitializationType',['../dd/d18/namespaceanpi.html#a57664960c64a6275e3bf1c70d6fab177',1,'anpi']]]
];
