var searchData=
[
  ['old_5findex',['old_index',['../dd/d67/classanpi_1_1ThermalPlate.html#a249cb0a0909e3d47bbdf9e65db1e6a46',1,'anpi::ThermalPlate']]],
  ['operator_21_3d',['operator!=',['../de/dee/classanpi_1_1Matrix.html#ac5dc646cee3d1a736acfa431076e1f37',1,'anpi::Matrix']]],
  ['operator_28_29',['operator()',['../de/dee/classanpi_1_1Matrix.html#a956c10f1e9f46bdc4a09919f4ecc1de1',1,'anpi::Matrix::operator()(const size_t row, const size_t col)'],['../de/dee/classanpi_1_1Matrix.html#adfd71caad2eb4c7b32b93e15217dc2cd',1,'anpi::Matrix::operator()(const size_t row, const size_t col) const']]],
  ['operator_2a',['operator*',['../dd/d18/namespaceanpi.html#a2b732f1fc647ede34024f3441c37ae45',1,'anpi::operator*(const Matrix&lt; T, Alloc &gt; &amp;a, const Matrix&lt; T, Alloc &gt; &amp;b)'],['../dd/d18/namespaceanpi.html#a1f9baeaf135f590f648d63c1a019670c',1,'anpi::operator*(const Matrix&lt; T, Alloc &gt; &amp;a, const std::vector&lt; T &gt; &amp;b)']]],
  ['operator_2b',['operator+',['../dd/d18/namespaceanpi.html#a423316157aca85d7aefff3fcee900a5e',1,'anpi']]],
  ['operator_2b_3d',['operator+=',['../de/dee/classanpi_1_1Matrix.html#a41117c04ff2155dbf8c7af63dd82c245',1,'anpi::Matrix']]],
  ['operator_2d',['operator-',['../dd/d18/namespaceanpi.html#a96bd9f3072f6ea35a1d8b5a3f2ff09ae',1,'anpi']]],
  ['operator_2d_3d',['operator-=',['../de/dee/classanpi_1_1Matrix.html#aedd6690382a1f26e2300ba25bb389b8b',1,'anpi::Matrix']]],
  ['operator_3d',['operator=',['../de/dee/classanpi_1_1Matrix.html#a94adb04f158cd8045eaef69fa47effc6',1,'anpi::Matrix::operator=(const Matrix&lt; T, Alloc &gt; &amp;other)'],['../de/dee/classanpi_1_1Matrix.html#a59ccc766804762b9ec9a2186cbddbacc',1,'anpi::Matrix::operator=(const Matrix&lt; T, OAlloc &gt; &amp;other)'],['../de/dee/classanpi_1_1Matrix.html#a7995acac7bc35fe918dbec071c2b2359',1,'anpi::Matrix::operator=(Matrix&lt; T, Alloc &gt; &amp;&amp;other)']]],
  ['operator_3d_3d',['operator==',['../de/dee/classanpi_1_1Matrix.html#aa3ea7a77b2c5e5e5b7ef95bde6981a85',1,'anpi::Matrix']]],
  ['operator_5b_5d',['operator[]',['../de/dee/classanpi_1_1Matrix.html#a26b55be70c6d8719bf59b2ca32f6c8b4',1,'anpi::Matrix::operator[](const size_t row)'],['../de/dee/classanpi_1_1Matrix.html#a1795fbe980e38936d36065831ef3d3a6',1,'anpi::Matrix::operator[](const size_t row) const']]]
];
