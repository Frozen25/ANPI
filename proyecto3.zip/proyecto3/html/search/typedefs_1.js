var searchData=
[
  ['cmatrix',['cmatrix',['../dc/dbd/testMatrix_8cpp.html#aee253d69508f432c433649e3f9f55d76',1,'testMatrix.cpp']]],
  ['const_5fpointer',['const_pointer',['../de/dee/classanpi_1_1Matrix.html#ac6d45526407ea4455424debdc4f21b91',1,'anpi::Matrix']]]
];
