var searchData=
[
  ['dcomplex',['dcomplex',['../dc/dbd/testMatrix_8cpp.html#aa7b4cfa83fe868296abd1ba4d67d9563',1,'testMatrix.cpp']]],
  ['dmatrix',['dmatrix',['../dc/dbd/testMatrix_8cpp.html#a1ceeaf72bfc7a6234b3e6eb6a60d3ef3',1,'testMatrix.cpp']]]
];
