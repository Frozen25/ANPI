var searchData=
[
  ['anpi',['anpi',['../dd/d18/namespaceanpi.html',1,'']]],
  ['benchmark',['benchmark',['../dc/de2/namespaceanpi_1_1benchmark.html',1,'anpi']]],
  ['fallback',['fallback',['../d6/d4d/namespaceanpi_1_1fallback.html',1,'anpi']]],
  ['simd',['simd',['../d6/d42/namespaceanpi_1_1simd.html',1,'anpi']]],
  ['test',['test',['../da/dd4/namespaceanpi_1_1test.html',1,'anpi']]]
];
