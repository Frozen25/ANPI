var searchData=
[
  ['add',['add',['../d6/d4d/namespaceanpi_1_1fallback.html#a24c6fc021f114dc70158be580ee78fda',1,'anpi::fallback::add(const Matrix&lt; T, Alloc &gt; &amp;a, const Matrix&lt; T, Alloc &gt; &amp;b, Matrix&lt; T, Alloc &gt; &amp;c)'],['../d6/d4d/namespaceanpi_1_1fallback.html#a7618281e2e5eff8773323b9815f974ab',1,'anpi::fallback::add(Matrix&lt; T, Alloc &gt; &amp;a, const Matrix&lt; T, Alloc &gt; &amp;b)'],['../d6/d42/namespaceanpi_1_1simd.html#ae4ef1d42aea6476578a669fb8c7109a1',1,'anpi::simd::add(const Matrix&lt; T, Alloc &gt; &amp;a, const Matrix&lt; T, Alloc &gt; &amp;b, Matrix&lt; T, Alloc &gt; &amp;c)'],['../d6/d42/namespaceanpi_1_1simd.html#a254bbb0c28defbf2348e5197607d61bc',1,'anpi::simd::add(Matrix&lt; T, Alloc &gt; &amp;a, const Matrix&lt; T, Alloc &gt; &amp;b)']]],
  ['add_5foptions',['add_options',['../df/df5/program__options_8cpp.html#adcfd0453184884b727a51cfe2b2d870a',1,'program_options.cpp']]],
  ['addsimd',['addSIMD',['../d6/d42/namespaceanpi_1_1simd.html#a68e80d90707dc4526ef25ded81768ad0',1,'anpi::simd']]],
  ['allocate',['allocate',['../de/dee/classanpi_1_1Matrix.html#ad052d3579194efb15c5d98b6edc43893',1,'anpi::Matrix']]]
];
