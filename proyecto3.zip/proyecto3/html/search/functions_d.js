var searchData=
[
  ['pivot',['pivot',['../dd/d18/namespaceanpi.html#a28b5b58719a454e2a5e8343a9c035d06',1,'anpi']]],
  ['plot',['plot',['../d6/dfc/classanpi_1_1Plot2d.html#a0b04dd4c40f9f623789fa688bd3c593d',1,'anpi::Plot2d::plot(const std::vector&lt; T &gt; &amp;datax, const std::vector&lt; T &gt; &amp;datay, const std::string &amp;legend, const std::string &amp;color=&quot;&quot;)'],['../d6/dfc/classanpi_1_1Plot2d.html#ad7978a6d763c92036ca249982a041dd1',1,'anpi::Plot2d::plot(const std::vector&lt; T &gt; &amp;datax, const std::vector&lt; T &gt; &amp;averagey, const std::vector&lt; T &gt; &amp;miny, const std::vector&lt; T &gt; &amp;maxy, const std::string &amp;legend, const std::string &amp;color=&quot;r&quot;)'],['../dc/de2/namespaceanpi_1_1benchmark.html#a2342edf4630c65e3bb493d4327aaf2e5',1,'anpi::benchmark::plot()']]],
  ['plot2d',['Plot2d',['../d6/dfc/classanpi_1_1Plot2d.html#a0d7d01999364a90882de6b19bdd0245b',1,'anpi::Plot2d']]],
  ['plotrange',['plotRange',['../dc/de2/namespaceanpi_1_1benchmark.html#a58babb1b967728c138790779206a61a1',1,'anpi::benchmark']]],
  ['plotthermal',['plotThermal',['../d6/dfc/classanpi_1_1Plot2d.html#aea73e92ff640dc6e16fbe0fd3e588667',1,'anpi::Plot2d']]],
  ['prepare',['prepare',['../d9/d9d/classbenchAdd.html#a42b0ce6b2d78a84bb89e135517f65d4a',1,'benchAdd::prepare()'],['../d6/dfc/classbenchSub.html#a00120c49297be543c5d5e65289405eec',1,'benchSub::prepare()']]],
  ['pymat_5frow',['pymat_row',['../dd/d18/namespaceanpi.html#a924781fa0b7a5031d898921010dbd01c',1,'anpi']]]
];
