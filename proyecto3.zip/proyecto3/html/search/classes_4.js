var searchData=
[
  ['is_5faligned_5falloc',['is_aligned_alloc',['../d8/d38/structanpi_1_1is__aligned__alloc.html',1,'anpi']]],
  ['is_5faligned_5falloc_3c_20anpi_3a_3aaligned_5fallocator_3c_20t_2c_20a_20_3e_20_3e',['is_aligned_alloc&lt; anpi::aligned_allocator&lt; T, A &gt; &gt;',['../d7/dd2/structanpi_1_1is__aligned__alloc_3_01anpi_1_1aligned__allocator_3_01T_00_01A_01_4_01_4.html',1,'anpi']]],
  ['is_5faligned_5falloc_3c_20anpi_3a_3aaligned_5frow_5fallocator_3c_20t_2c_20a_20_3e_20_3e',['is_aligned_alloc&lt; anpi::aligned_row_allocator&lt; T, A &gt; &gt;',['../d7/ddf/structanpi_1_1is__aligned__alloc_3_01anpi_1_1aligned__row__allocator_3_01T_00_01A_01_4_01_4.html',1,'anpi']]],
  ['is_5fsimd_5ftype',['is_simd_type',['../de/d2e/structis__simd__type.html',1,'']]]
];
