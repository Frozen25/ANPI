var searchData=
[
  ['_5fcreate_5fstorage',['_create_storage',['../de/dee/classanpi_1_1Matrix.html#a4a02a0adb2750cabbbb8437d52b61452',1,'anpi::Matrix']]],
  ['_5fdeallocate',['_deallocate',['../de/dee/classanpi_1_1Matrix.html#abdb7fc545cefe3fb0efc62b2bfbd7ac2',1,'anpi::Matrix']]],
  ['_5fget_5fallocator',['_get_allocator',['../de/dee/classanpi_1_1Matrix.html#a8bd792b99ec2206cfcb8a6ff6a7e9219',1,'anpi::Matrix::_get_allocator() noexcept'],['../de/dee/classanpi_1_1Matrix.html#a49856d0af9e0fd8e47bedb487bedce7e',1,'anpi::Matrix::_get_allocator() const noexcept']]],
  ['_5fmatrix_5fimpl',['_Matrix_impl',['../d8/df4/structanpi_1_1Matrix_1_1__Matrix__impl.html#a7ee30810c49444c8eb481d22c0a82274',1,'anpi::Matrix::_Matrix_impl::_Matrix_impl()'],['../d8/df4/structanpi_1_1Matrix_1_1__Matrix__impl.html#a1451d484426e27bf75cd914342f8cb20',1,'anpi::Matrix::_Matrix_impl::_Matrix_impl(allocator_type const &amp;_a) noexcept'],['../d8/df4/structanpi_1_1Matrix_1_1__Matrix__impl.html#a6d2a88ab7ffecd955a5d624f38e96752',1,'anpi::Matrix::_Matrix_impl::_Matrix_impl(allocator_type &amp;&amp;_a) noexcept']]],
  ['_5fswap_5fdata',['_swap_data',['../d8/df4/structanpi_1_1Matrix_1_1__Matrix__impl.html#ac7fa3cfa2d4ee9e2a1f9b77671169601',1,'anpi::Matrix::_Matrix_impl']]]
];
