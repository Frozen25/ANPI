var searchData=
[
  ['grid',['grid',['../dd/d67/classanpi_1_1ThermalPlate.html#a09c6cb5df28bbc7ce19b0361ffdd20f3',1,'anpi::ThermalPlate']]]
];
