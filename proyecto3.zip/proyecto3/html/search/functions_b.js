var searchData=
[
  ['new_5findex',['new_index',['../dd/d67/classanpi_1_1ThermalPlate.html#a8d8872e95750a5cd5ae6e1a89b60cbd8',1,'anpi::ThermalPlate']]]
];
