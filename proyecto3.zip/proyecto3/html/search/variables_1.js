var searchData=
[
  ['aligned',['aligned',['../d1/da2/structanpi_1_1extract__alignment.html#a88d37e5eb4f071220ab7f2b09945b096',1,'anpi::extract_alignment::aligned()'],['../d6/dd5/structanpi_1_1extract__alignment_3_01Alloc_3_01T_00_01Align_01_4_01_4.html#ab95bd1ca2b281ba457d80c9de368c2f2',1,'anpi::extract_alignment&lt; Alloc&lt; T, Align &gt; &gt;::aligned()']]],
  ['alignment',['alignment',['../d8/df4/structanpi_1_1Matrix_1_1__Matrix__impl.html#abaf34526e81f2208ca054d4b88599409',1,'anpi::Matrix::_Matrix_impl']]],
  ['average',['average',['../d9/d9d/structanpi_1_1benchmark_1_1measurement.html#a5042a3e3484c5867043109ea00e58051',1,'anpi::benchmark::measurement']]]
];
