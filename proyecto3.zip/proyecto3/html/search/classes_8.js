var searchData=
[
  ['thermalplate',['ThermalPlate',['../dd/d67/classanpi_1_1ThermalPlate.html',1,'anpi']]]
];
