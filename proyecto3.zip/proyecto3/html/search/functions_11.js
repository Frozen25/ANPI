var searchData=
[
  ['tentries',['tentries',['../d8/df4/structanpi_1_1Matrix_1_1__Matrix__impl.html#af9a5caaabb241f1acb9b275e3a0898ad',1,'anpi::Matrix::_Matrix_impl']]],
  ['testarithmetic',['testArithmetic',['../dc/dbd/testMatrix_8cpp.html#ac136fd2699d3eaae7e83bc614ab1a029',1,'testMatrix.cpp']]],
  ['testassignment',['testAssignment',['../dc/dbd/testMatrix_8cpp.html#a6511448e831e8802408d21a5ccd67b82',1,'testMatrix.cpp']]],
  ['testcomparison',['testComparison',['../dc/dbd/testMatrix_8cpp.html#a6908e553a5673d1e31fff72b8fdff7db',1,'testMatrix.cpp']]],
  ['testconstructors',['testConstructors',['../dc/dbd/testMatrix_8cpp.html#abdd34c9253834ddbd54b4b5b0a070a40',1,'testMatrix.cpp']]],
  ['testsimd',['testSimd',['../dc/dbd/testMatrix_8cpp.html#ac598b3b6de606c671db3acb3f86460be',1,'testMatrix.cpp']]],
  ['thermal',['thermal',['../dc/de2/namespaceanpi_1_1benchmark.html#a9835c451c061a81b48e64c5c055c3768',1,'anpi::benchmark']]],
  ['thermalplate',['ThermalPlate',['../dd/d67/classanpi_1_1ThermalPlate.html#a39bd162b401db270c8c304efc5bb98c1',1,'anpi::ThermalPlate::ThermalPlate()=default'],['../dd/d67/classanpi_1_1ThermalPlate.html#ac48332c6a6deef37d73a60a1cf6fe3b7',1,'anpi::ThermalPlate::ThermalPlate(bool isolatedTop, bool isolatedBottom, bool isolatedLeft, bool isolatedRight, std::vector&lt; float &gt; &amp;top, std::vector&lt; float &gt; &amp;bottom, std::vector&lt; float &gt; &amp;left, std::vector&lt; float &gt; &amp;right, bool showThermalFlow, bool noVisuals, int grid, int horizontal, int vertical)']]],
  ['topbar',['TopBar',['../dd/d67/classanpi_1_1ThermalPlate.html#a8894638c9cce3fc9b615a6930ca0d8cd',1,'anpi::ThermalPlate']]],
  ['transpose',['transpose',['../de/dee/classanpi_1_1Matrix.html#a302741339084245047d417815cc13a62',1,'anpi::Matrix']]]
];
