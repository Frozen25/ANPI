var searchData=
[
  ['novisuals',['noVisuals',['../dd/d67/classanpi_1_1ThermalPlate.html#a1730343425724196f24a3340487f078d',1,'anpi::ThermalPlate']]]
];
