var searchData=
[
  ['_7ematrix',['~Matrix',['../de/dee/classanpi_1_1Matrix.html#ab27bf73e875186026c86483660292762',1,'anpi::Matrix']]],
  ['_7eplot2d',['~Plot2d',['../d6/dfc/classanpi_1_1Plot2d.html#a0a9ba35b064aef73a9c6f601b2345734',1,'anpi::Plot2d']]]
];
