var searchData=
[
  ['quiver',['quiver',['../d6/dfc/classanpi_1_1Plot2d.html#ab2d6160a61a3c1173588765eeccb0491',1,'anpi::Plot2d::quiver()'],['../dc/de2/namespaceanpi_1_1benchmark.html#a7780fd16b79ca29deebddc3494da1886',1,'anpi::benchmark::quiver()']]],
  ['quiver1d',['quiver1D',['../d6/dfc/classanpi_1_1Plot2d.html#ad70dc094e12bc263dc196c1b96656f47',1,'anpi::Plot2d::quiver1D()'],['../dc/de2/namespaceanpi_1_1benchmark.html#a5595edd07bd29c91ca3b040e2601efb7',1,'anpi::benchmark::quiver1D()']]]
];
