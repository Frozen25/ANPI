var searchData=
[
  ['exception',['Exception',['../de/d35/classanpi_1_1Exception.html',1,'anpi']]],
  ['extract_5falignment',['extract_alignment',['../d1/da2/structanpi_1_1extract__alignment.html',1,'anpi']]],
  ['extract_5falignment_3c_20alloc_3c_20t_2c_20align_20_3e_20_3e',['extract_alignment&lt; Alloc&lt; T, Align &gt; &gt;',['../d6/dd5/structanpi_1_1extract__alignment_3_01Alloc_3_01T_00_01Align_01_4_01_4.html',1,'anpi']]]
];
