var searchData=
[
  ['new_5findex',['new_index',['../dd/d67/classanpi_1_1ThermalPlate.html#a8d8872e95750a5cd5ae6e1a89b60cbd8',1,'anpi::ThermalPlate']]],
  ['novisuals',['noVisuals',['../dd/d67/classanpi_1_1ThermalPlate.html#a1730343425724196f24a3340487f078d',1,'anpi::ThermalPlate']]]
];
