var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvw~",
  1: "_abeimprt",
  2: "at",
  3: "abcefhilmopstu",
  4: "_abcdefgilmnopqrstuvw~",
  5: "_abcefghilmnorstv",
  6: "acdfioprv",
  7: "i",
  8: "d",
  9: "abcdghps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones",
  5: "Variables",
  6: "typedefs",
  7: "Enumeraciones",
  8: "Valores de enumeraciones",
  9: "defines"
};

