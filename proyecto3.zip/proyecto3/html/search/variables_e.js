var searchData=
[
  ['showthermalflow',['showThermalFlow',['../dd/d67/classanpi_1_1ThermalPlate.html#a71037bf9aaa9f0ea7098a0ff635a186e',1,'anpi::ThermalPlate']]],
  ['size',['size',['../d9/d9d/structanpi_1_1benchmark_1_1measurement.html#afe0cb29662f49075ef729d726d8909da',1,'anpi::benchmark::measurement']]],
  ['stddev',['stddev',['../d9/d9d/structanpi_1_1benchmark_1_1measurement.html#a24c713323a95c68d1e4b510e5aebfe7e',1,'anpi::benchmark::measurement']]]
];
