var searchData=
[
  ['max',['max',['../d9/d9d/structanpi_1_1benchmark_1_1measurement.html#a82b78290c5c00f8b5e612dd71b0568d5',1,'anpi::benchmark::measurement']]],
  ['min',['min',['../d9/d9d/structanpi_1_1benchmark_1_1measurement.html#aa828898bfade7034026d8e6167288a97',1,'anpi::benchmark::measurement']]]
];
