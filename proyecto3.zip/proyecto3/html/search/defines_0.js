var searchData=
[
  ['anpi_5fbenchmark',['ANPI_BENCHMARK',['../dc/dcc/benchmarkFramework_8hpp.html#ac92c101c2820680d2c3934979bdf3ae2',1,'benchmarkFramework.hpp']]],
  ['anpi_5fdata_5fpath',['ANPI_DATA_PATH',['../d5/dad/AnpiConfig_8hpp.html#a8935b66f2cdfb84adbb7c9c4baa0da81',1,'AnpiConfig.hpp']]],
  ['anpi_5fenable_5fopenmp',['ANPI_ENABLE_OpenMP',['../d5/dad/AnpiConfig_8hpp.html#abfac8e349d5e793894531f99eb5066f8',1,'AnpiConfig.hpp']]],
  ['anpi_5fenable_5fsimd',['ANPI_ENABLE_SIMD',['../d5/dad/AnpiConfig_8hpp.html#aa9162188d35e9d8fa729962dbe177f03',1,'AnpiConfig.hpp']]],
  ['anpi_5flu_5fhpp',['ANPI_LU_HPP',['../d6/dcf/LU_8hpp.html#af951373acdeee8477120e7f95fa31f04',1,'LU.hpp']]],
  ['anpi_5fsolver_5fhpp',['ANPI_SOLVER_HPP',['../d1/d19/Solver_8hpp.html#a6d331c9de915c72f3b549942259de276',1,'Solver.hpp']]],
  ['architecture_5fid',['ARCHITECTURE_ID',['../d6/d83/CMakeCXXCompilerId_8cpp.html#aba35d0d200deaeb06aee95ca297acb28',1,'CMakeCXXCompilerId.cpp']]]
];
