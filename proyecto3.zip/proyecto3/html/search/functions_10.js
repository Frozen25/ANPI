var searchData=
[
  ['scale_5fmatrix',['scale_matrix',['../dd/d67/classanpi_1_1ThermalPlate.html#af85b4a7783b8ff9b4660c8a3e959d0a9',1,'anpi::ThermalPlate']]],
  ['setgridsize',['setGridSize',['../d6/dfc/classanpi_1_1Plot2d.html#a24be2607e97fdf82267c53f1cdc1c620',1,'anpi::Plot2d']]],
  ['settitle',['setTitle',['../d6/dfc/classanpi_1_1Plot2d.html#a4346f9f252a2637696ef94ce3755d04a',1,'anpi::Plot2d']]],
  ['setxlabel',['setXLabel',['../d6/dfc/classanpi_1_1Plot2d.html#a64b1163ea264ff3eec9f222d82b92052',1,'anpi::Plot2d']]],
  ['setxrange',['setXRange',['../d6/dfc/classanpi_1_1Plot2d.html#aad762639127c43070ba584a3c438cf52',1,'anpi::Plot2d']]],
  ['setylabel',['setYLabel',['../d6/dfc/classanpi_1_1Plot2d.html#a689b16faa995ca545fe13088cbd382a5',1,'anpi::Plot2d']]],
  ['setyrange',['setYRange',['../d6/dfc/classanpi_1_1Plot2d.html#a5bac0f99358cd81f048cc5c5bc69ffda',1,'anpi::Plot2d']]],
  ['show',['show',['../d6/dfc/classanpi_1_1Plot2d.html#a41165ac70edb258fa0fbcce04ddf7025',1,'anpi::Plot2d::show()'],['../dc/de2/namespaceanpi_1_1benchmark.html#ad790ffd5a54be367b4ffa1fd862f9ba2',1,'anpi::benchmark::show()']]],
  ['solvelu',['solveLU',['../dd/d18/namespaceanpi.html#a6764a07c6b16cedf0489a10e2650cc51',1,'anpi']]],
  ['solvelutest',['solveLUTest',['../da/dd4/namespaceanpi_1_1test.html#a48305a842ca50e8175b4baa93d9fc70e',1,'anpi::test']]],
  ['solveplate',['solvePlate',['../dd/d67/classanpi_1_1ThermalPlate.html#a8f3535a477baff44346118527ff42090',1,'anpi::ThermalPlate']]],
  ['sqr',['sqr',['../dc/de2/namespaceanpi_1_1benchmark.html#ad4af8012fb125ce95037fbf5e5d003eb',1,'anpi::benchmark']]],
  ['subsimd',['subSIMD',['../d6/d42/namespaceanpi_1_1simd.html#a6637f725450fe3bbc39506a28152264f',1,'anpi::simd']]],
  ['substitutiontest',['substitutionTest',['../da/dd4/namespaceanpi_1_1test.html#a9d30d26dcfe2c4fe8c7c98c71546d734',1,'anpi::test']]],
  ['subtract',['subtract',['../d6/d4d/namespaceanpi_1_1fallback.html#a5edefd65be498d783018b1a7a8bf48b0',1,'anpi::fallback::subtract(const Matrix&lt; T, Alloc &gt; &amp;a, const Matrix&lt; T, Alloc &gt; &amp;b, Matrix&lt; T, Alloc &gt; &amp;c)'],['../d6/d4d/namespaceanpi_1_1fallback.html#a33e33fc558cc7712504723cd2d9ac5b9',1,'anpi::fallback::subtract(Matrix&lt; T, Alloc &gt; &amp;a, const Matrix&lt; T, Alloc &gt; &amp;b)'],['../d6/d42/namespaceanpi_1_1simd.html#a78848ed9be16434f4e6ee7ca6f56f14d',1,'anpi::simd::subtract(const Matrix&lt; T, Alloc &gt; &amp;a, const Matrix&lt; T, Alloc &gt; &amp;b, Matrix&lt; T, Alloc &gt; &amp;c)'],['../d6/d42/namespaceanpi_1_1simd.html#a623f6cf02845caed74338093e0162ef9',1,'anpi::simd::subtract(Matrix&lt; T, Alloc &gt; &amp;a, const Matrix&lt; T, Alloc &gt; &amp;b)']]],
  ['swap',['swap',['../de/dee/classanpi_1_1Matrix.html#a137779b37d7ececd016a16398c02ee67',1,'anpi::Matrix']]],
  ['swaprows',['swapRows',['../dd/d18/namespaceanpi.html#a7b518e385d9e5b7eb141d31fce717247',1,'anpi']]]
];
