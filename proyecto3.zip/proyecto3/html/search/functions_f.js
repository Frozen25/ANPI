var searchData=
[
  ['rightbar',['RightBar',['../dd/d67/classanpi_1_1ThermalPlate.html#a227bb49bbfb8de325707360f88a1be01',1,'anpi::ThermalPlate']]],
  ['rows',['rows',['../de/dee/classanpi_1_1Matrix.html#a44ad72297afd1e3cf0b4586f004243f5',1,'anpi::Matrix']]]
];
