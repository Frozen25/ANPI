var searchData=
[
  ['pointer',['pointer',['../de/dee/classanpi_1_1Matrix.html#a6d2754ddec71081f6e1c0e4c320e8f8e',1,'anpi::Matrix']]]
];
