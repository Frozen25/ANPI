var searchData=
[
  ['platform_5fid',['PLATFORM_ID',['../d6/d83/CMakeCXXCompilerId_8cpp.html#adbc5372f40838899018fadbc89bd588b',1,'CMakeCXXCompilerId.cpp']]]
];
