var searchData=
[
  ['row_5faligned',['row_aligned',['../d4/df0/classanpi_1_1aligned__row__allocator.html#a948213c2c7edb9227302f18045428b13',1,'anpi::aligned_row_allocator']]]
];
