var searchData=
[
  ['ompver_5fstr',['ompver_str',['../de/d68/OpenMPCheckVersion_8cpp.html#af60b110d3c4507a1d6ffd66d846f1c58',1,'OpenMPCheckVersion.cpp']]]
];
