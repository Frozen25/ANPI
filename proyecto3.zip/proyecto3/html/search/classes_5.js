var searchData=
[
  ['matrix',['Matrix',['../de/dee/classanpi_1_1Matrix.html',1,'anpi']]],
  ['matrix_3c_20t_20_3e',['Matrix&lt; T &gt;',['../de/dee/classanpi_1_1Matrix.html',1,'anpi']]],
  ['measurement',['measurement',['../d9/d9d/structanpi_1_1benchmark_1_1measurement.html',1,'anpi::benchmark']]]
];
